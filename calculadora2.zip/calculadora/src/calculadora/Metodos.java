/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author juanj
 */
public class Metodos {
    //atributos
    private String cadena;
    private double resultado;
    private  boolean sqrt;
    private  boolean pow;
    private  boolean sen;
    private  boolean cos;
    private  boolean tan;
public Metodos(){
    cadena="";
    resultado = 0;
    sqrt = false;
    pow = false;
    sen = false;
    cos = false;
    tan = false;
    } 
public void addn(double numero){
    resultado = numero;
}
public void operacion(String operador, double numero) {
        switch (operador) {
            case "+" -> {resultado += numero;
            
            }
            case "-" -> resultado -= numero;
            case "*" -> resultado *= numero;
            case "/" -> {
                if (numero != 0) {
                    resultado /= numero;
                } else {
                    System.out.println("Syntax Error!!!");
                }
            }
            case "√" -> resultado = Math.sqrt(numero);
            case "^" -> resultado = Math.pow(resultado, numero);
            default -> System.out.println("Operación no válida");
            
        }
       
    }
public double sen(double n){
    return Math.sin(n);
}
public double cos(double n){
    return Math.cos(n);
}
public double tan(double n){
    return Math.tan(n);
}
public double obResultado(){
    return resultado;
}
public String conect(String cadena){
    this.cadena=this.cadena+cadena;
    return this.cadena;
   }
public void borrar(String cadena){
    this.cadena="";
   }
}
